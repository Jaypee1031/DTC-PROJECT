<?php
// Include the database connection
include('db_connection.php');

// Start the session
session_start();

// Check if the user is logged in
if (isset($_SESSION['user'])) {
    $username = $_SESSION['user']; // Get the username from the session
    $action = "User viewed finished reports"; // Define the action to log

    // Log the user action
    $logStmt = $conn->prepare("INSERT INTO user_logs (username, action) VALUES (?, ?)");
    $logStmt->bind_param("ss", $username, $action);
    $logStmt->execute();
    $logStmt->close();
} else {
    // Handle the case where the user is not logged in
    // You can redirect them to the login page or show an error message
    header('Location: login.php');
    exit();
}

// Fetch finished reports from the database
$stmt = $conn->prepare("SELECT * FROM reports WHERE status = 'Finished' ORDER BY created_at DESC");
$stmt->execute();
$reports = $stmt->get_result();

// Fetch user details
$userDetails = [];
if (isset($_SESSION['id'])) {
    $userId = $_SESSION['id'];
    $userStmt = $conn->prepare("SELECT email, barangay, municipality, purok FROM users WHERE id = ?");
    if ($userStmt) {
        $userStmt->bind_param("s", $userId);
        $userStmt->execute();
        $userResult = $userStmt->get_result();
        
        // Check if any user details were returned
        if ($userResult->num_rows > 0) {
            $userDetails = $userResult->fetch_assoc();
        } else {
            // No user found with the given ID
            echo "<script>alert('No user found with the given ID.');</script>";
        }
        $userStmt->close();
    } else {
        echo "<script>alert('Error preparing statement: " . $conn->error . "');</script>";
    }
} else {
    echo "<script>alert('User ID not found in session.');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MDRRMO</title>
    <link rel='stylesheet' href='//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>
    <link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.3/animate.min.css'>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/">
                <img src="assets/images/IISE.png" alt="Logo" style="height: 30px; width: 30px; display: inline-block; vertical-align: middle; margin-right: 8px;">
                IISE DRRM 
            </a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#" id="userDetailsLink" data-toggle="modal" data-target="#userDetailsModal"><span class="glyphicon glyphicon-user">&nbsp;</span>Hello</a></li>
                <li class="active"><a title="View Website" href="#"><span class="glyphicon glyphicon-globe"></span></a></li>
                <li>
                    <a href="#" data-toggle="dropdown" class="dropdown-toggle" id="notificationBell">
                        <span class="glyphicon glyphicon-bell"></span>
                        <?php
                        $stmt = $conn->prepare("SELECT * FROM reports WHERE status IS NULL");
                        $stmt->execute();
                        $unreadReports = $stmt->get_result();
                        $unread_report_count = $unreadReports->num_rows;
                        if ($unread_report_count > 0) {
                            echo '<span class="badge">' . $unread_report_count . '</span>';
                        }
                        ?>
                    </a>
                    <ul class="dropdown-menu" id="notificationDropdown">
                        <?php
                        $stmt = $conn->prepare("SELECT * FROM reports WHERE status IS NULL ORDER BY created_at DESC LIMIT 5");
                        $stmt->execute();
                        $latestReports = $stmt->get_result();
                        while ($report = $latestReports->fetch_assoc()) {
                            echo '<li><a href="#">Report #' . $report['id'] . ': ' . $report['incident_type'] . '</a></li>';
                        }
                        ?>
                    </ul>
                </li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
  <div class="col-md-3">
    <div id="sidebar">
      <div class="container-fluid tmargin">
  <div class="input-group">
    <input type="text" id="searchInput" class="form-control" placeholder="Search...">
    <span class="input-group-btn">
      <button id="searchButton" class="btn btn-default">
        <span class="glyphicon glyphicon-search"></span>
      </button>
    </span>
  </div>
</div>
        <ul class="nav navbar-nav side-bar">
            <li class="side-bar"><a href="admin_dashboard.php"><span class="glyphicon glyphicon-list">&nbsp;</span>Dashboard</a></li>
            
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-file">&nbsp;</span>Reports <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="finished_reports.php"><span class="glyphicon glyphicon-ok">&nbsp;</span>Finished Reports</a></li>
                    <li><a href="rejected_reports.php"><span class="glyphicon glyphicon-remove">&nbsp;</span>Rejected Reports</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-signal">&nbsp;</span>Statistics <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="semi_annual_statistics.php"><span class="glyphicon glyphicon-calendar">&nbsp;</span>Semi-Annual</a></li>
                    <li><a href="quarterly_statistics.php"><span class="glyphicon glyphicon-calendar">&nbsp;</span>Quarterly</a></li>
                    <li><a href="monthly_statistics.php"><span class="glyphicon glyphicon-calendar">&nbsp;</span>Monthly</a></li>
                    <li><a href="weekly_statistics.php"><span class="glyphicon glyphicon-calendar">&nbsp;</span>Weekly</a></li>
                    <li><a href="barangay_statistics.php"><span class="glyphicon glyphicon-map-marker ">&nbsp;</span>Barangay</a></li>
                    <li><a href="accident_type.php"><span class="glyphicon glyphicon-list-alt">&nbsp;</span>Reported Accident Type</a></li>
                </ul>
            </li>
            <li class="side-bar"><a href="report_image.php"><span class="glyphicon glyphicon-cog">&nbsp;</span>Report Image</a></li>
            <li class="side-bar"><a href="user_management.php"><span class="glyphicon glyphicon-user">&nbsp;</span>User Management</a></li>
            <li class="side-bar"><a href="logs.php"><span class="glyphicon glyphicon-book">&nbsp;</span>Logs</a></li>
            
            <li class="side-bar"><a href="add_report.php"><span class="glyphicon glyphicon-plus">&nbsp;</span>Add Report</a></li>
            <li class="side-bar"><a href="add_user.php"><span class="glyphicon glyphicon-plus">&nbsp;</span>Add User</a></li>
                        <li class="side-bar"><a href="update_hotlines.php"><span class="glyphicon glyphicon-plus">&nbsp;</span>Update Hotlines</a></li>
        </ul>
    </div>
</div>

    <div class="col-md-9">
        <h1 class="page-header">Finished Reports</h1>
        <ul class="breadcrumb">
            <li><span class="glyphicon glyphicon-home">&nbsp;</span>Home</li>
            <li><a href="#">Finished Reports</a></li>
        </ul>
        <h2>Reports</h2>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>&nbsp;</th>
                    <th class="text-center">ID</th>
                    <th>Respondent Name</th>
                    <th class="text-center">Location</th>
                    <th class="text-center">Accident Type</th>
                    <th class="text-center">Phone Number</th>
                    <th class="text-center">Incident Image</th>
                    <th class="text-center">Created At</th>
                    <th class="text-center">Spot Report</th>
                    <th class="text-center">After Duty Report</th>
                    <th class="text-center">Ambulance Dispatch log</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($report = $reports->fetch_assoc()) {
                    ?>
                    <tr>
                        <td>&nbsp;</td>
                        <td class="text-center"><?php echo $report['id']; ?></td>
                        <td><?php echo $report['respondent_name']; ?></td>
                        <td class="text-center"><?php echo $report['location']; ?></td>
                        <td><?php echo $report['incident_type']; ?></td>
                        <td class="text-center"><?php echo $report['phone_number']; ?></td>
                        <td class="text-center">
                            <?php
                            $image_paths = json_decode($report['incident_image'], true); // Decode JSON
                            if (!empty($image_paths)) {
                                foreach ($image_paths as $image_path) {
                                    if (file_exists($image_path)) {
                                        echo '<a href="#" data-toggle="modal" data-target="#imageModal" data-image="' . htmlspecialchars($image_path) . '"><img src="' . $image_path . '" width="100" height="100"></a>';
                                    } else {
                                        echo '<a href="#" data-toggle="modal" data-target="#imageModal" data-image="' . htmlspecialchars($image_path) . '"><img src="default_image.jpg" width="100" height="100"></a>';
                                    }
                                }
                            } else {
                                echo 'No images available';
                            }
                            ?>
                        </td>
                        <td class="text-center"><?php echo date('m-d-Y h:i:s A', strtotime($report['created_at'])); ?></td>
                        <td class="text-center">
                            <a href="pdf_maker.php?id=<?php echo $report['id']; ?>" class="btn btn-info">View PDF</a>
                            <a href="update_report.php?id=<?php echo $report['id']; ?>" class="btn btn-warning">Update PDF</a>
                        </td>
                        <td class="text-center">
                            <a href="generate_pdf.php?id=<?php echo $report['id']; ?>" class="btn btn-info">View PDF</a>
                            <a href="add_after_duty_report.php?id=<?php echo $report['id']; ?>" class="btn btn-warning">Add Report PDF</a>
                        </td>
                        <td class="text-center">
                            <a href="?id=<?php echo $report['id']; ?>" class="btn btn-info">View PDF</a>
                            <a href="?id=<?php echo $report['id']; ?>" class="btn btn-warning">Add Report PDF</a>
                            <?php
                            // Check if the After Duty Report PDF exists
                            $after_duty_report_path = $report['after_duty_report'];
                            if (!empty($after_duty_report_path) && file_exists($after_duty_report_path)) {
                                echo '<a href="' . $after_duty_report_path . '" class="btn btn-success" download>Download PDF</a>';
                            }
                            ?>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal for viewing image -->
<div id="imageModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="imageModalLabel">Incident Image</h4>
      </div>
      <div class="modal-body">
        <img src="" id="modalImage" class="img-responsive" />
      </div>
    </div>
  </div>
</div>
<!-- Modal for viewing user details -->
<div id="userDetailsModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="userDetailsModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="userDetailsModalLabel">User Details</h4>
      </div>
      <div class="modal-body">
        <p><strong>Email:</strong> <?php echo isset($userDetails['email']) ? $userDetails['email'] : 'N/A'; ?></p>
        <p><strong>Barangay:</strong> <?php echo isset($userDetails['barangay']) ? $userDetails['barangay'] : 'N/A'; ?></p>
        <p><strong>Municipality:</strong> <?php echo isset($userDetails['municipality']) ? $userDetails['municipality'] : 'N/A'; ?></p>
        <p><strong>Purok:</strong> <?php echo isset($userDetails['purok']) ? $userDetails['purok'] : 'N/A'; ?></p>
      </div>
    </div>
  </div>
</div>
<script src='//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js'></script>
<script src='//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
// JavaScript for image modal
$('#imageModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); 
    var imageSrc = button.data('image'); 
    var modal = $(this);
    modal.find('#modalImage').attr('src', imageSrc);
});
// Animation for notification bell
if (<?php echo $unread_report_count; ?> > 0) {
  $('#notificationBell').addClass('animated infinite bounce');
} else {
  $('#notificationBell').removeClass('animated infinite bounce');
}
$(document).ready(function() {
    $("#searchButton").click(function() {
      var query = $("#searchInput").val().toLowerCase(); // Get search input

      // Loop through table rows and show/hide based on search query
      $("table tbody tr").each(function() {
        var rowText = $(this).text().toLowerCase();
        if (rowText.includes(query)) {
          $(this).show();
        } else {
          $(this).hide();
        }
      });
    });

    // Allow Enter key to trigger search
    $("#searchInput").keypress(function(e) {
      if (e.which == 13) { // 13 is Enter key
        $("#searchButton").click();
      }
    });
  });
</script>
</body>
</html>
